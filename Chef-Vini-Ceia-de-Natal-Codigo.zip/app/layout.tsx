import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Chef Vini — O Natal à Mesa",
  description: "Seu Natal merece mais presença. Conheça a proposta do Kit de Ceia de Natal do Chef Vini e consulte seu menu pelo WhatsApp.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
